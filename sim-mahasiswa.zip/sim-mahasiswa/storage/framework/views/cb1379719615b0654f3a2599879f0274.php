

<?php $__env->startSection('judul', 'Detail Mahasiswa'); ?>

<?php $__env->startSection('konten'); ?>
    <h1>Detail Mahasiswa</h1>

    <table>
        <tr>
            <th>NIM</th>
            <td><?php echo e($mhs['nim']); ?></td>
        </tr>
        <tr>
            <th>Nama</th>
            <td><?php echo e($mhs['nama']); ?></td>
        </tr>
        <tr>
            <th>Program Studi</th>
            <td><?php echo e($mhs['prodi']); ?></td>
        </tr>
        <tr>
            <th>Angkatan</th>
            <td><?php echo e($mhs['angkatan']); ?></td>
        </tr>
        <tr>
            <th>Status</th>
            <td><?php echo e(ucfirst($mhs['status'])); ?></td>
        </tr>
    </table>

    <p><a href="<?php echo e(route('mahasiswa.index')); ?>">&larr; Kembali ke daftar</a></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sim-mahasiswa\resources\views/mahasiswa/show.blade.php ENDPATH**/ ?>