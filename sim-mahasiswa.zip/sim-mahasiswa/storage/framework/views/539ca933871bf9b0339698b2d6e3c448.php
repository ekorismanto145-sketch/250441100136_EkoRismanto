

<?php $__env->startSection('judul', 'Daftar Mahasiswa'); ?>

<?php $__env->startSection('konten'); ?>
    <h1>Daftar Mahasiswa</h1>

    <?php if(count($mahasiswa) > 0): ?>
        <p>Total: <?php echo e(count($mahasiswa)); ?> mahasiswa</p>

        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>NIM</th>
                    <th>Nama</th>
                    <th>Angkatan</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($mhs['nim']); ?></td>
                        <td><?php echo e($mhs['nama']); ?></td>
                        <td><?php echo e($mhs['angkatan']); ?></td>
                        <td>
                            <span class="badge badge-<?php echo e($mhs['status']); ?>">
                                <?php echo e(ucfirst($mhs['status'])); ?>

                            </span>
                        </td>
                        <td>
                            <a href="<?php echo e(route('mahasiswa.show', $mhs['nim'])); ?>">Detail</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Belum ada data mahasiswa.</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sim-mahasiswa\resources\views/mahasiswa/index.blade.php ENDPATH**/ ?>