<footer>
    &copy; <?php echo e(date('Y')); ?> Sistem Informasi Mahasiswa
</footer>
<?php /**PATH C:\laragon\www\sim-mahasiswa\resources\views/partials/footer.blade.php ENDPATH**/ ?>