

<?php $__env->startSection('judul', 'Kontak'); ?>

<?php $__env->startSection('konten'); ?>
    <h1>Kontak</h1>
    <p>Email: support@sim-mahasiswa.ac.id</p>
    <ul>
        <li>Senin - Jumat: 08.00 - 16.00 WIB</li>
        <li>Sabtu: 08.00 - 12.00 WIB</li>
    </ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sim-mahasiswa\resources\views/kontak.blade.php ENDPATH**/ ?>