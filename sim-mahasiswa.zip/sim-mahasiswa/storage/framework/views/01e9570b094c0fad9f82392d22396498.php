

<?php $__env->startSection('judul', 'Tentang'); ?>

<?php $__env->startSection('konten'); ?>
    <h1>Tentang Aplikasi</h1>
    <p>Aplikasi ini dibuat sebagai media pembelajaran untuk memahami konsep dasar Laravel Blade Templating, Komponen, dan Routing.</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sim-mahasiswa\resources\views/tentang.blade.php ENDPATH**/ ?>