<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['judul' => 'Tanpa Judul']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['judul' => 'Tanpa Judul']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="kartu">
    <h3><?php echo e($judul); ?></h3>
    <div class="isi">
        <?php echo e($slot); ?>

    </div>
    <?php if(isset($footer)): ?>
        <div class="kaki">
            <?php echo e($footer); ?>

        </div>
    <?php endif; ?>
</div><?php /**PATH C:\laragon\www\sim-mahasiswa\resources\views/components/kartu.blade.php ENDPATH**/ ?>