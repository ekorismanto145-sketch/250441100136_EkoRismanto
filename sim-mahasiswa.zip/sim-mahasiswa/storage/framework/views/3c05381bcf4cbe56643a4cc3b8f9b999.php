

<?php $__env->startSection('judul', 'Profil Mahasiswa'); ?>

<?php $__env->startSection('konten'); ?>
    <h1>Profil Mahasiswa</h1>

    <table>
        <tr>
            <th>Nama</th>
            <td><?php echo e($nama); ?></td>
        </tr>
        <tr>
            <th>NIM</th>
            <td><?php echo e($nim); ?></td>
        </tr>
        <tr>
            <th>Program Studi</th>
            <td><?php echo e($prodi); ?></td>
        </tr>
        <tr>
            <th>Angkatan</th>
            <td><?php echo e($angkatan); ?></td>
        </tr>
    </table>

    <p>Selamat datang, <?php echo e($nama); ?>!</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sim-mahasiswa\resources\views/mahasiswa/profil.blade.php ENDPATH**/ ?>