

<?php $__env->startSection('judul', 'Beranda'); ?>

<?php $__env->startSection('konten'); ?>
    <h1>Sistem Informasi Mahasiswa</h1>
    <p>Selamat datang di aplikasi latihan Laravel Modul 1.</p>
    <p><a href="<?php echo e(route('mahasiswa.index')); ?>">Lihat daftar mahasiswa &rarr;</a></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sim-mahasiswa\resources\views/beranda.blade.php ENDPATH**/ ?>