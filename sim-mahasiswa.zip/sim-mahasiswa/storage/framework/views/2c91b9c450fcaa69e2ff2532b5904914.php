<nav>
    <a href="<?php echo e(route('beranda')); ?>" class="<?php echo e(request()->routeIs('beranda') ? 'aktif' : ''); ?>">Beranda</a>
    <a href="<?php echo e(route('mahasiswa.index')); ?>" class="<?php echo e(request()->routeIs('mahasiswa.index', 'mahasiswa.show') ? 'aktif' : ''); ?>">Mahasiswa</a>
    <a href="<?php echo e(route('mahasiswa.profil')); ?>" class="<?php echo e(request()->routeIs('mahasiswa.profil') ? 'aktif' : ''); ?>">Profil</a>
    <a href="<?php echo e(route('dashboard')); ?>" class="<?php echo e(request()->routeIs('dashboard') ? 'aktif' : ''); ?>">Dashboard</a>
    <a href="<?php echo e(route('tentang')); ?>" class="<?php echo e(request()->routeIs('tentang') ? 'aktif' : ''); ?>">Tentang</a>
    <a href="<?php echo e(route('kontak')); ?>" class="<?php echo e(request()->routeIs('kontak') ? 'aktif' : ''); ?>">Kontak</a>
</nav><?php /**PATH C:\laragon\www\sim-mahasiswa\resources\views/partials/navbar.blade.php ENDPATH**/ ?>